package com.java5.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.java5.dao.ProductDAO;
import com.java5.entity.Product;

@Controller
public class AdminProductController {

    @Autowired
    private ProductDAO productDAO;

    @RequestMapping("/adproduct")
    public String index(Model model) {
        Product product = new Product();
        model.addAttribute("product", product);
        List<Product> products = productDAO.findAll();
        model.addAttribute("products", products);
        return "adminproduct";
    }
    @GetMapping("/adprosearch")
    public String searchProduct(@RequestParam("keyword") String keyword, Model model) {
        List<Product> products = productDAO.searchAllColumns(keyword);
        model.addAttribute("products", products);
        return "adminproduct";
    }
//    @GetMapping("/adproduct/edit/{productId}")
//    public String edit(Model model, @PathVariable("productId") String productId) {
//        Optional<Product> productOptional = productDAO.findById(productId);
//        if (productOptional.isPresent()) {
//            Product product = productOptional.get();
//            model.addAttribute("product", product);
//        } else {
//            // Thông báo khi không tìm thấy sản phẩm
//            model.addAttribute("errorMessage", "Không tìm thấy sản phẩm");
//        }
//        List<Product> products = productDAO.findAll();
//        model.addAttribute("products", products);
//        return "adminproduct";
//    }

    @PostMapping("/adproduct/create")
    public String create(@ModelAttribute("product") Product product) {
        productDAO.save(product);
        return "redirect:/adproduct";
    }

    @RequestMapping(value = "/adproduct/update", method = RequestMethod.POST)
    public String update(@ModelAttribute("product") Product product) {
        productDAO.save(product);
        return "redirect:/adproduct" ;
    }



    @RequestMapping("/adproduct/delete/{productId}")
    public String delete(@PathVariable("productId") String productId) {
        productDAO.deleteById(productId);
        return "redirect:/adproduct";
    }
}