package com.java5.controller;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.java5.dao.ProductDAO;
import com.java5.entity.Product;

@Controller
public class ProductsListController {
    @Autowired
    private ProductDAO productDAO;

    @GetMapping("/products")
    public String showAllProducts(Model model) {
        List<Product> products = productDAO.findAll();
        model.addAttribute("products", products);
        return "productlist";
    }

    @GetMapping("/search")
    public String search(@RequestParam(name = "min", required = false) Double minPrice,
                         @RequestParam(name = "max", required = false) Double maxPrice,
                         @RequestParam(name = "brand", required = false) List<String> brands,
                         Model model) {
        List<Product> products;

        if (minPrice != null && maxPrice != null) {
            products = productDAO.findByPrice(minPrice, maxPrice);
        } else {
            products = productDAO.findAll();
        }

        if (brands != null && !brands.isEmpty()) {
            List<Product> brandFilteredProducts = brands.stream()
                    .flatMap(brand -> productDAO.findByKeyword(brand).stream())
                    .collect(Collectors.toList());

            if (minPrice != null && maxPrice != null) {
                brandFilteredProducts = brandFilteredProducts.stream()
                        .filter(p -> p.getPrice() >= minPrice && p.getPrice() <= maxPrice)
                        .collect(Collectors.toList());
            }
            products = brandFilteredProducts;
        }

        products.sort((p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()));
        model.addAttribute("products", products);
        return "productlist";
    }

    @GetMapping("/product")
    public String getProductById(@RequestParam("id") String productId, Model model) {
        Product product = productDAO.findByProductId(productId);
        model.addAttribute("product", product);
        
        // Lấy ba sản phẩm ngẫu nhiên
        List<Product> allProducts = productDAO.findAll();
        List<Product> randomProducts = allProducts.stream()
                .filter(p -> !p.getProductId().equals(productId)) // Loại bỏ sản phẩm hiện tại
                .collect(Collectors.collectingAndThen(Collectors.toList(), 
                    collected -> {
                        Random rand = new Random();
                        return rand.ints(0, collected.size())
                                .distinct()
                                .limit(3)
                                .mapToObj(collected::get)
                                .collect(Collectors.toList());
                    }));
        
        model.addAttribute("randomProducts", randomProducts);
        return "detailproduct"; // tên của trang JSP mà bạn muốn hiển thị
    }
}