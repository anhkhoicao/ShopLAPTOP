package com.java5.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.java5.dao.CartDAO;
import com.java5.dao.ProductDAO;
import com.java5.entity.Cart;
import com.java5.entity.Product;

@Controller
@RequestMapping("/cart")
public class CartController {

	@Autowired
	private CartDAO cDAO;

	@Autowired
	private ProductDAO pDAO;

	@GetMapping("/view")
	public String viewCart(Model model) {
		List<Cart> cartItems = cDAO.findAll();
		double totalAmount = 0;
		for (Cart item : cartItems) {
			totalAmount += item.getQuantity() * item.getTotal_payment();
		}
		model.addAttribute("totalAmount", totalAmount);
		model.addAttribute("cartItems", cartItems);
		return "cart";
	}

	@PostMapping("/add/{productId}")
	public String addProductToCart(@PathVariable String productId) {
	    // Tìm kiếm thông tin sản phẩm trong cơ sở dữ liệu dựa trên productId
	    Optional<Product> productOptional = pDAO.findById(productId);

	    if (productOptional.isPresent()) {
	        Product product = productOptional.get();

	        // Tìm kiếm sản phẩm trong giỏ hàng dựa trên productId
	        List<Cart> cartItems = cDAO.findByProduct(product);
	        if (!cartItems.isEmpty()) {
	            // Nếu sản phẩm đã tồn tại trong giỏ hàng, cập nhật số lượng và tổng thanh toán
	            Cart cartItem = cartItems.get(0);
	            cartItem.setQuantity(cartItem.getQuantity() + 1);
	            cartItem.setTotal_payment(cartItem.getDiscounted_price() * cartItem.getQuantity());
	            cDAO.save(cartItem);
	        } else {
	            // Nếu sản phẩm chưa tồn tại trong giỏ hàng, tạo mới sản phẩm vào giỏ hàng
	            Cart cartItem = new Cart();
	            cartItem.setProduct(product);
	            cartItem.setProduct_name(product.getProductName());
	            cartItem.setImage(product.getImage());
	            cartItem.setQuantity(1); // Mặc định số lượng là 1
	            cartItem.setDiscounted_price(product.getDiscountedPrice()); // Giá sau khi giảm giá
	            cartItem.setTotal_payment(product.getPrice() - product.getDiscountedPrice()); // Tổng thanh toán ban đầu là giá sau khi giảm giá
	            cDAO.save(cartItem);
	        }
	    }

	    // Chuyển hướng người dùng đến trang giỏ hàng sau khi thêm sản phẩm
	    return "redirect:/cart/view";
	}


	@PostMapping("/update")
	public String update(@RequestParam("cart_id") Integer id, @RequestParam("quantity") Integer qty) {
		Optional<Cart> cartItemOptional = cDAO.findById(id); // Lấy thông tin sản phẩm trong giỏ hàng
		if (cartItemOptional.isPresent()) {
			Cart cartItem = cartItemOptional.get(); // Truy cập đối tượng Cart từ Optional
			cartItem.setQuantity(qty); // Cập nhật số lượng mới
			cartItem.setTotal_payment(cartItem.getDiscounted_price() * qty); // Tính toán lại tổng giá dựa trên số lượng
																				// mới
			cDAO.save(cartItem); // Lưu thông tin sản phẩm đã cập nhật
		}
		return "redirect:/cart/view"; // Chuyển hướng lại trang giỏ hàng
	}
	// Delete from cart
		@PostMapping("/delete")
		public String deleteFromCart(@RequestParam("cart_id") Integer cartId) {
			cDAO.deleteById(cartId); // Xóa sản phẩm khỏi giỏ hàng theo cart_id
			return "redirect:/cart/view"; // Chuyển hướng lại trang giỏ hàng
		}

		// Clear cart
		@PostMapping("/clear")
		public String clearCart() {
			cDAO.deleteAll(); // Xóa tất cả sản phẩm trong giỏ hàng
			return "redirect:/cart/view"; // Chuyển hướng lại trang giỏ hàng
		}

	}