package com.java5.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.java5.dao.OrderDAO;
import com.java5.entity.Order;

@Controller
@RequestMapping("/adorder")
public class AdminOrderController {

    @Autowired
    private OrderDAO orderDAO;

    @GetMapping
    public String showOrderManagement(Model model) {
        List<Order> orders = orderDAO.findAll();
        model.addAttribute("orders", orders);
        return "adminorder";
    }

    @PostMapping("/adordersearch")
    public String searchOrderManagement(@RequestParam("keyword") String keyword, Model model) {
        List<Order> orders = orderDAO.searchAllColumns(keyword);
        model.addAttribute("orders", orders);
        return "adminorder";
    }

    // Add other methods to interact with the database for orders
}