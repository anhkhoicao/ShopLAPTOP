package com.java5.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.java5.dao.OrderDAO;
import com.java5.entity.TypeReport;

@Controller
@RequestMapping("/reporttype")
public class AdminTypeReportController {

    @Autowired
    private OrderDAO orderDAO;

    @GetMapping
    public String showProductTypeReport(Model model) {
        List<TypeReport> statistics = orderDAO.getStatisticsByProductType();
        model.addAttribute("statistics", statistics);
        return "admintypereport";
    }
}