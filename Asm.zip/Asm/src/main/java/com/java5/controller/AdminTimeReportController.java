package com.java5.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.java5.dao.OrderDAO;
import com.java5.entity.TimeReport;

import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/reporttime")
public class AdminTimeReportController {

    @Autowired
    private OrderDAO orderDAO;
    
    @GetMapping
    public String showUserManagement() {
        return "admintimereport";
    }

    @PostMapping("/timesearch")
    public String showOrderManagement(@RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
                                      @RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate,
                                      Model model) {
        List<TimeReport> statistics = orderDAO.getStatisticsByTime(startDate, endDate);
        // In ra log để kiểm tra
        System.out.println("Start Date: " + startDate);
        System.out.println("End Date: " + endDate);
        System.out.println("Statistics: " + statistics);
        for (TimeReport stat : statistics) {
            System.out.println("Gaming Quantity: " + stat.getGamingQuantity());
            System.out.println("Standard Quantity: " + stat.getStandardQuantity());
            System.out.println("Total Revenue: " + stat.getTotalRevenue());
        }
        model.addAttribute("statistics", statistics);
        return "admintimereport";
    }


    // Add other methods to interact with the database for orders
}