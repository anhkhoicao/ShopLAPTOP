package com.java5.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.java5.dao.UserDAO;
import com.java5.entity.User;

@Controller
public class AccountController {
    @Autowired
    UserDAO dao;

    @RequestMapping("/account/register")
    public String registerPage(Model model) {
        User newUser = new User();
        model.addAttribute("newUser", newUser);
        return "register";
    }
    @RequestMapping("/account/login")
    public String loginPage(Model model) {
        User newUser = new User();
        model.addAttribute("newUser", newUser);
        return "login";
    }

    @RequestMapping("/account/create")
    public String createAccount(User newUser, Model model) {
        if (!dao.existsById(newUser.getUser_id())) {
            // Đặt các giá trị mặc định
            newUser.setRole(false); // giá trị mặc định cho role
            newUser.setActivated(true); // giá trị mặc định cho activated
            model.addAttribute("message", "Tạo tài khoản thành công");
            dao.save(newUser);
            return "redirect:/account/login";
        }
        model.addAttribute("message", "Mã tài khoản này đã tồn tại!");
        return "account";
    }


    @RequestMapping("/account/logindone")
    public String login(@RequestParam("user_id") String user_id, @RequestParam("password") String password, Model model) {
        Optional<User> userOpt = dao.findById(user_id);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (user.getPassword().equals(password)) {
            	if (user.getRole()) { // Assuming 'role' is of type Boolean and admin role is true
                    return "redirect:/admin"; // Redirect to admin page
                } else {
                    return "redirect:/index"; // Redirect to user page
                }
            }
        }
        model.addAttribute("message", "Tài khoản hoặc mật khẩu không chính xác!");
        return "login";
    }
}
