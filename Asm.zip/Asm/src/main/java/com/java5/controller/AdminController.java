package com.java5.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @GetMapping
    public String showAdminDashboard() {
        return "admin";
    }

    @GetMapping("/productmanagement")
    public RedirectView showProductManagement() {
        return new RedirectView("/adproduct");
    }

    @GetMapping("/ordermanagement")
    public RedirectView showOrderManagement() {
        return new RedirectView("/adorder");
    }

    @GetMapping("/usermanagement")
    public RedirectView showUserManagement() {
        return new RedirectView("/aduser");
    }

    @GetMapping("/typereport")
    public RedirectView showTypeReport() {
        return new RedirectView("/reporttype");
    }

    @GetMapping("/timereport")
    public RedirectView showTimeReport() {
        return new RedirectView("/reporttime");
    }
}
