package com.java5.entity;

import java.io.Serializable;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "users")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	String user_id;
	String password;
	String name;
	String photo;
	String phone;
	String email;
	Boolean role;
	Boolean activated;

	@OneToMany(mappedBy = "user")
	List<FavoriteCount> favoriteCounts;

	// Constructor mặc định
	public User() {
		this.role = false; // giá trị mặc định cho role
		this.activated = true; // giá trị mặc định cho activated
	}

	// Constructor có tham số
	public User(String user_id, String password, String name, String photo, String phone, String email, Boolean role,
			Boolean activated, List<Cart> carts, List<FavoriteCount> favoriteCounts) {
		super();
		this.user_id = user_id;
		this.password = password;
		this.name = name;
		this.photo = photo;
		this.phone = phone;
		this.email = email;
		this.role = role;
		this.activated = activated;
		this.favoriteCounts = favoriteCounts;
	}

	// Getters and setters (nếu không sử dụng Lombok, nhưng ở đây bạn đã dùng @Data)
	// ...

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Boolean getRole() {
		return role;
	}

	public void setRole(Boolean role) {
		this.role = role;
	}

	public Boolean getActivated() {
		return activated;
	}

	public void setActivated(Boolean activated) {
		this.activated = activated;
	}

	public List<FavoriteCount> getFavoriteCounts() {
		return favoriteCounts;
	}

	public void setFavoriteCounts(List<FavoriteCount> favoriteCounts) {
		this.favoriteCounts = favoriteCounts;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}