package com.java5.entity;

public class TimeReport {
    private Long gamingQuantity;
    private Long standardQuantity;
    private Double totalRevenue;

    public TimeReport() {
    }

    public TimeReport(Long gamingQuantity, Long standardQuantity, Double totalRevenue) {
        this.gamingQuantity = gamingQuantity;
        this.standardQuantity = standardQuantity;
        this.totalRevenue = totalRevenue;
    }

    public Long getGamingQuantity() {
        return gamingQuantity;
    }

    public void setGamingQuantity(Long gamingQuantity) {
        this.gamingQuantity = gamingQuantity;
    }

    public Long getStandardQuantity() {
        return standardQuantity;
    }

    public void setStandardQuantity(Long standardQuantity) {
        this.standardQuantity = standardQuantity;
    }

    public Double getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(Double totalRevenue) {
        this.totalRevenue = totalRevenue;
    }
}