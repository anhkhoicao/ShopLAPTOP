package com.java5.entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "orders")
public class Order implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer order_id;

    @ManyToOne
    @JoinColumn(name = "cart_id")
    Cart cart;

    @Temporal(TemporalType.DATE)
    Date create_date;

    String phone;
    String email;
    String address;
    String product_name;
    Boolean type;
    Integer quantity;
    Double discounted_price;
    Double total_payment;
	public Order() {
		super();
	}
	public Order(Integer order_id, Cart cart, Date create_date, String phone, String email, String address,
			String product_name, Boolean type, Integer quantity, Double discounted_price, Double total_payment) {
		super();
		this.order_id = order_id;
		this.cart = cart;
		this.create_date = create_date;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.product_name = product_name;
		this.type = type;
		this.quantity = quantity;
		this.discounted_price = discounted_price;
		this.total_payment = total_payment;
	}
	public Integer getOrder_id() {
		return order_id;
	}
	public void setOrder_id(Integer order_id) {
		this.order_id = order_id;
	}
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	public Date getCreate_date() {
		return create_date;
	}
	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public Boolean getType() {
		return type;
	}
	public void setType(Boolean type) {
		this.type = type;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Double getDiscounted_price() {
		return discounted_price;
	}
	public void setDiscounted_price(Double discounted_price) {
		this.discounted_price = discounted_price;
	}
	public Double getTotal_payment() {
		return total_payment;
	}
	public void setTotal_payment(Double total_payment) {
		this.total_payment = total_payment;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
    
    
}
	