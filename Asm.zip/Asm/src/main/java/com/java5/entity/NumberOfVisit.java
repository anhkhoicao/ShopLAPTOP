package com.java5.entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "number_of_visit")
public class NumberOfVisit implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    Date date_id;
    Integer number_of_visitors;
	public NumberOfVisit() {
		super();
	}
	public NumberOfVisit(Date date_id, Integer number_of_visitors) {
		super();
		this.date_id = date_id;
		this.number_of_visitors = number_of_visitors;
	}
	public Date getDate_id() {
		return date_id;
	}
	public void setDate_id(Date date_id) {
		this.date_id = date_id;
	}
	public Integer getNumber_of_visitors() {
		return number_of_visitors;
	}
	public void setNumber_of_visitors(Integer number_of_visitors) {
		this.number_of_visitors = number_of_visitors;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    
}