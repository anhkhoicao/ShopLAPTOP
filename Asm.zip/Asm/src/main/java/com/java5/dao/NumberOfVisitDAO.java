package com.java5.dao;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import com.java5.entity.NumberOfVisit;

public interface NumberOfVisitDAO extends JpaRepository<NumberOfVisit, Date> {
}
