package com.java5.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.java5.entity.FavoriteCount;

public interface FavoriteCountDAO extends JpaRepository<FavoriteCount, Integer> {
}
