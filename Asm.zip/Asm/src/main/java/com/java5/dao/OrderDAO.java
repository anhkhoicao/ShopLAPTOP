package com.java5.dao;

import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.java5.entity.Order;
import com.java5.entity.TimeReport;
import com.java5.entity.TypeReport;


public interface OrderDAO extends JpaRepository<Order, Integer> {
	
	@Query(value = "SELECT * FROM orders WHERE order_id LIKE %:keyword% OR create_date LIKE %:keyword% OR phone LIKE %:keyword% OR email LIKE %:keyword% OR address LIKE %:keyword% OR product_name LIKE %:keyword% OR quantity LIKE %:keyword% OR discounted_price LIKE %:keyword% OR total_payment LIKE %:keyword%", nativeQuery = true)
	List<Order> searchAllColumns(@Param("keyword") String keyword);

	@Query(value = "SELECT new TypeReport(o.type, sum(o.total_payment), count(o)) "
            + "FROM Order o "
            + "GROUP BY o.type "
            + "ORDER BY sum(o.total_payment) DESC")
    List<TypeReport> getStatisticsByProductType();
	
	@Query(value = "SELECT * FROM orders WHERE create_date BETWEEN :startDate AND :endDate", nativeQuery = true)
    List<Order> findByCreateDateBetween(@Param("startDate") Date startDate, @Param("endDate") Date endDate);

    @Query(value = "SELECT new com.java5.entity.TimeReport(SUM(CASE WHEN o.type = true THEN 1 ELSE 0 END), "
            + "SUM(CASE WHEN o.type = false THEN 1 ELSE 0 END), "
            + "SUM(o.total_payment)) "
            + "FROM Order o "
            + "WHERE o.create_date BETWEEN :startDate AND :endDate")
    List<TimeReport> getStatisticsByTime(@Param("startDate") Date startDate, @Param("endDate") Date endDate);
	
}