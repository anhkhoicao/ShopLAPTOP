package com.java5.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.java5.entity.Product;

public interface ProductDAO extends JpaRepository<Product, String> {
	@Query(value = "SELECT * FROM products WHERE price BETWEEN :min AND :max", nativeQuery = true)
	List<Product> findByPrice(@Param("min")double min, @Param("max")double max);
	@Query(value = "SELECT * FROM products WHERE product_name LIKE %:keyword%", nativeQuery = true)
    List<Product> findByKeyword(@Param("keyword") String keyword);
	@Query(value = "SELECT * FROM products WHERE product_id = :productId", nativeQuery = true)
    Product findByProductId(@Param("productId") String productId);
	@Query(value = "SELECT * FROM products WHERE product_id LIKE %:keyword% OR product_name LIKE %:keyword% OR brand LIKE %:keyword% OR color LIKE %:keyword%", nativeQuery = true)
    List<Product> searchAllColumns(@Param("keyword") String keyword);
}