package com.java5.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.java5.entity.Cart;
import com.java5.entity.Product;

public interface CartDAO extends JpaRepository<Cart, Integer> {
    List<Cart> findByProduct(Product product);
}

